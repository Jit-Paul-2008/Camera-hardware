package com.hq.recorder

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    data class Mode(val label: String, val size: Size, val fps: Int, val hs: Boolean, val range: Range<Int>)

    private lateinit var cm: CameraManager
    private lateinit var tv: TextureView
    private lateinit var frame: FrameLayout
    private lateinit var modeSpin: Spinner
    private lateinit var hevcSw: Switch
    private lateinit var aeSw: Switch
    private lateinit var prevSw: Switch
    private var curHs = false
    private lateinit var brSeek: SeekBar
    private lateinit var brTxt: TextView
    private lateinit var evSeek: SeekBar
    private lateinit var evTxt: TextView
    private lateinit var statusTv: TextView
    private lateinit var timerTv: TextView
    private lateinit var recBtn: Button
    private lateinit var camBtn: Button

    private var back = true
    private var camId: String? = null
    private var chars: CameraCharacteristics? = null
    private var modes: List<Mode> = emptyList()
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var builder: CaptureRequest.Builder? = null
    private var recorder: MediaRecorder? = null
    private var recUri: Uri? = null
    private var recPfd: ParcelFileDescriptor? = null
    private var recording = false
    private var evMin = 0
    private var evStep = 0f
    @Volatile private var evVal = 0
    @Volatile private var aeLock = false
    private var t0 = 0L
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var ht: HandlerThread
    private lateinit var h: Handler

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hasCam() = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private fun status(s: String) = runOnUiThread { statusTv.text = s }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cm = getSystemService(CAMERA_SERVICE) as CameraManager
        ht = HandlerThread("cam").also { it.start() }
        h = Handler(ht.looper)
        buildUi()
        if (!hasCam()) requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
        else initCamera()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        if (hasCam()) initCamera() else status("Camera permission is needed. Allow it in Settings > Apps > HQ Recorder.")
    }

    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.LTGRAY); textSize = 13f; setPadding(0, dp(10), 0, dp(2)) }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.BLACK) }
        frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        tv = TextureView(this)
        frame.addView(tv, FrameLayout.LayoutParams(100, 100, Gravity.CENTER))
        frame.addOnLayoutChangeListener { _, l, t, r, bt, _, _, _, _ -> fit(r - l, bt - t) }
        root.addView(frame, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(14)) }
        statusTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; text = "Starting..." }
        timerTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 20f; text = "0:00" }
        recBtn = Button(this).apply { text = "Record"; setOnClickListener { if (recording) stopRecording() else startRecording() } }
        camBtn = Button(this).apply {
            text = "Camera: Back"
            setOnClickListener {
                if (recording) return@setOnClickListener
                back = !back
                text = if (back) "Camera: Back" else "Camera: Front"
                closeCamera(); initCamera()
            }
        }
        modeSpin = Spinner(this)
        hevcSw = Switch(this).apply { text = "HEVC (H.265)"; isChecked = true; setTextColor(Color.WHITE) }
        prevSw = Switch(this).apply { text = "Preview during slow-mo (can break 4K)"; isChecked = false; setTextColor(Color.WHITE) }
        aeSw = Switch(this).apply {
            text = "Lock exposure"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, c -> aeLock = c; push() }
        }
        brTxt = TextView(this).apply { setTextColor(Color.WHITE) }
        brSeek = SeekBar(this).apply {
            max = 140; progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { brTxt.text = "Bitrate: ${10 + p} Mbps" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        brTxt.text = "Bitrate: 60 Mbps"
        evTxt = TextView(this).apply { setTextColor(Color.WHITE); text = "Exposure: 0.0 EV" }
        evSeek = SeekBar(this).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    evVal = p + evMin
                    evTxt.text = "Exposure: " + String.format("%.1f", evVal * evStep) + " EV"
                    if (u) push()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(timerTv); col.addView(recBtn); col.addView(statusTv)
        col.addView(label("Mode (what this phone reports)")); col.addView(modeSpin)
        col.addView(hevcSw); col.addView(prevSw); col.addView(brTxt); col.addView(brSeek)
        col.addView(evTxt); col.addView(evSeek); col.addView(aeSw); col.addView(camBtn)
        val sv = ScrollView(this).apply { addView(col) }
        root.addView(sv, LinearLayout.LayoutParams(dp(320), ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, hh: Int) {
                if (!hasCam()) return
                if (chars == null) initCamera() else if (device != null) startPreview() else openCamera()
            }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, hh: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
    }

    private fun fit(fw: Int, fh: Int) {
        if (fw <= 0 || fh <= 0) return
        var w = fw
        var hh = w * 9 / 16
        if (hh > fh) { hh = fh; w = hh * 16 / 9 }
        val lp = tv.layoutParams
        if (lp.width != w || lp.height != hh) { lp.width = w; lp.height = hh; tv.layoutParams = lp }
    }

    private fun is169(s: Size) = Math.abs(s.width.toDouble() / s.height - 16.0 / 9.0) < 0.02
    private fun nm(s: Size) = when {
        s.width >= 3800 -> "4K"; s.width >= 2500 -> "2K"; s.width >= 1900 -> "1080p"; else -> "720p"
    } + " ${s.width}x${s.height}"

    private fun pickRange(rs: Array<Range<Int>>, f: Int): Range<Int> =
        rs.filter { it.upper == f }.maxByOrNull { it.lower }
            ?: rs.filter { it.upper >= f && it.lower <= f }.minByOrNull { it.upper }
            ?: Range(f, f)

    private fun initCamera() {
        val want = if (back) CameraCharacteristics.LENS_FACING_BACK else CameraCharacteristics.LENS_FACING_FRONT
        camId = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == want }
        val id = camId
        if (id == null) { status("No such camera"); return }
        val c = cm.getCameraCharacteristics(id)
        chars = c
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val rs = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: arrayOf(Range(30, 30))
        val list = ArrayList<Mode>()
        val sizes = map.getOutputSizes(MediaRecorder::class.java) ?: emptyArray()
        for (s in sizes.filter { is169(it) && it.width >= 1280 }.sortedByDescending { it.width }) {
            for (f in listOf(30, 60)) {
                if (f == 60 && rs.none { it.upper >= 60 }) {
                    if (s.width >= 2500) list.add(Mode(nm(s) + " @ 60 fps (not listed, try)", s, 60, false, Range(60, 60)))
                    continue
                }
                list.add(Mode(nm(s) + " @ " + f + " fps", s, f, false, pickRange(rs, f)))
            }
        }
        val normal = list.size
        var hsCount = 0
        try {
            for (s in map.highSpeedVideoSizes.sortedByDescending { it.width }) {
                for (r in map.getHighSpeedVideoFpsRangesFor(s).sortedByDescending { it.lower }) {
                    if (r.upper >= 60 && list.none { it.hs && it.size == s && it.fps == r.upper }) {
                        list.add(Mode("Slow-mo " + nm(s) + " @ " + r.upper + " fps", s, r.upper, true, r)); hsCount++
                    }
                }
            }
        } catch (e: Exception) {}
        modes = list
        modeSpin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, list.map { it.label })
        val def = list.indexOfFirst { !it.hs && it.fps == 30 && it.size.width in 3800..4200 }
        modeSpin.setSelection(if (def >= 0) def else 0)
        val er = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: Range(0, 0)
        evStep = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0.1f
        evMin = er.lower
        evSeek.max = er.upper - er.lower
        evSeek.progress = -er.lower
        status("Phone reports $normal standard modes and $hsCount slow-mo modes." +
            if (hsCount == 0) " No slow-mo exposed to apps on this camera." else "")
        if (tv.isAvailable) openCamera()
    }

    @SuppressLint("MissingPermission")
    private fun openCamera() {
        val id = camId ?: return
        if (device != null || !hasCam()) return
        try {
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) { device = d; startPreview() }
                override fun onDisconnected(d: CameraDevice) { d.close(); device = null }
                override fun onError(d: CameraDevice, e: Int) { d.close(); device = null; status("Camera error $e") }
            }, h)
        } catch (e: Exception) { status("Open failed: ${e.message}") }
    }

    private fun closeSession() { try { session?.close() } catch (e: Exception) {}; session = null }
    private fun closeCamera() { closeSession(); try { device?.close() } catch (e: Exception) {}; device = null }

    private fun previewSize(): Size {
        val map = chars!!.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val ss = map.getOutputSizes(SurfaceTexture::class.java)
        return ss.filter { is169(it) && it.width <= 1920 }.maxByOrNull { it.width } ?: ss[0]
    }

    private fun setCommon(b: CaptureRequest.Builder) {
        val c = chars ?: return
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        if (c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)?.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO) == true)
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
        b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evVal)
        b.set(CaptureRequest.CONTROL_AE_LOCK, aeLock)
        if (!curHs && c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.contains(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON) == true)
            b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
    }

    private fun push() {
        val s = session ?: return
        val b = builder ?: return
        try {
            setCommon(b)
            if (s is CameraConstrainedHighSpeedCaptureSession) s.setRepeatingBurst(s.createHighSpeedRequestList(b.build()), null, h)
            else s.setRepeatingRequest(b.build(), null, h)
        } catch (e: Exception) { status("Request failed: ${e.message}") }
    }

    private fun startPreview() {
        val d = device ?: return
        val t = tv.surfaceTexture ?: return
        if (chars == null) return
        closeSession()
        curHs = false
        runOnUiThread { tv.rotation = if (windowManager.defaultDisplay.rotation == Surface.ROTATION_270) 180f else 0f }
        try {
            val ps = previewSize()
            t.setDefaultBufferSize(ps.width, ps.height)
            val surf = Surface(t)
            d.createCaptureSession(listOf(surf), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    try {
                        val b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                        b.addTarget(surf); builder = b; push()
                    } catch (e: Exception) { status("Preview failed: ${e.message}") }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { status("Preview config failed") }
            }, h)
        } catch (e: Exception) { status("Preview failed: ${e.message}") }
    }

    private fun orientationHint(): Int {
        val rot = windowManager.defaultDisplay.rotation * 90
        val so = chars!!.get(CameraCharacteristics.SENSOR_ORIENTATION)!!
        return if (back) (so - rot + 360) % 360 else (so + rot) % 360
    }

    private fun discardRec() {
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        recUri?.let { try { contentResolver.delete(it, null, null) } catch (e: Exception) {} }
        recUri = null
        recording = false
    }

    private fun fail(msg: String) {
        discardRec()
        runOnUiThread { onRecState(false) }
        status(msg)
        startPreview()
    }

    private fun onRecState(on: Boolean) {
        recBtn.text = if (on) "Stop" else "Record"
        for (v in listOf<android.view.View>(modeSpin, hevcSw, brSeek, camBtn)) v.isEnabled = !on
        ui.removeCallbacksAndMessages(null)
        if (on) {
            t0 = System.currentTimeMillis()
            ui.post(object : Runnable {
                override fun run() {
                    val s = (System.currentTimeMillis() - t0) / 1000
                    timerTv.text = "REC " + s / 60 + ":" + String.format("%02d", s % 60)
                    ui.postDelayed(this, 500)
                }
            })
        } else timerTv.text = "0:00"
    }

    private fun startRecording() {
        val d = device ?: return
        val m = modes.getOrNull(modeSpin.selectedItemPosition) ?: return
        val t = tv.surfaceTexture ?: return
        closeSession()
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "HQ_" + System.currentTimeMillis() + ".mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HQRecorder")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
            val pfd = contentResolver.openFileDescriptor(uri, "w")!!
            val mr = MediaRecorder()
            recorder = mr; recUri = uri; recPfd = pfd; curHs = m.hs
            mr.setOnErrorListener { _, w, e -> status("Recorder error $w / $e") }
            val audio = !m.hs && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (audio) mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setOutputFile(pfd.fileDescriptor)
            mr.setVideoEncodingBitRate((10 + brSeek.progress) * 1_000_000)
            mr.setVideoFrameRate(m.fps)
            mr.setVideoSize(m.size.width, m.size.height)
            mr.setVideoEncoder(if (hevcSw.isChecked) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
            if (audio) {
                mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                mr.setAudioEncodingBitRate(256000)
                mr.setAudioSamplingRate(48000)
            }
            mr.setOrientationHint(orientationHint())
            mr.prepare()
            val ps = if (m.hs) m.size else previewSize()
            t.setDefaultBufferSize(ps.width, ps.height)
            val pSurf = Surface(t)
            val rSurf = mr.surface
            val usePrev = !m.hs || prevSw.isChecked
            val surfaces = if (usePrev) listOf(pSurf, rSurf) else listOf(rSurf)
            val cb = object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    try {
                        val b = d.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                        if (usePrev) b.addTarget(pSurf)
                        b.addTarget(rSurf)
                        b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, m.range)
                        builder = b
                        push()
                        if (m.hs) Thread.sleep(800)
                        mr.start()
                        recording = true
                        runOnUiThread { onRecState(true) }
                        status("Recording " + m.label + (if (hevcSw.isChecked) " HEVC " else " H.264 ") + (10 + brSeek.progress) + " Mbps")
                    } catch (e: Exception) { fail("Could not start: ${e.message}") }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { fail("This mode was rejected by the camera. Try another mode or H.264.") }
            }
            if (m.hs) d.createConstrainedHighSpeedCaptureSession(surfaces, cb, h)
            else d.createCaptureSession(surfaces, cb, h)
        } catch (e: Exception) { fail("Setup failed: ${e.message}") }
    }

    private fun stopRecording() {
        if (!recording) return
        recording = false
        try { session?.stopRepeating(); session?.abortCaptures() } catch (e: Exception) {}
        var ok = true
        var err = ""
        try { recorder?.stop() } catch (e: Exception) { ok = false; err = e.message ?: e.javaClass.simpleName }
        val bytes = try { recPfd?.statSize ?: 0L } catch (e: Exception) { 0L }
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        val u = recUri
        recUri = null
        if (u != null) {
            if (ok) {
                val cv = ContentValues(); cv.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(u, cv, null, null)
            } else contentResolver.delete(u, null, null)
        }
        closeSession()
        onRecState(false)
        val secs = (System.currentTimeMillis() - t0) / 1000.0
        status(if (ok) "Saved: " + String.format("%.1f", bytes / 1048576.0) + " MB in " + String.format("%.0f", secs) + " s (avg " + String.format("%.1f", bytes * 8 / 1e6 / secs) + " Mbps). Movies/HQRecorder"
        else "Failed, nothing saved: " + err + ". If this was 4K or slow-mo, the phone's encoder probably can't do it. Try 1080p 120, a lower bitrate, or H.264.")
        startPreview()
    }

    override fun onResume() {
        super.onResume()
        if (hasCam()) {
            if (chars == null) initCamera() else if (tv.isAvailable) openCamera()
        }
    }

    override fun onPause() {
        if (recording) stopRecording()
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        ht.quitSafely()
        super.onDestroy()
    }
}
