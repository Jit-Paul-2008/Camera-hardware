package com.hq.recorder

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.MeteringRectangle
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private val VW = 2560
    private val VH = 1440
    private val FPS = 60

    private lateinit var cm: CameraManager
    private lateinit var tv: TextureView
    private lateinit var frame: FrameLayout
    private lateinit var hevcSw: Switch
    private lateinit var aeSw: Switch
    private lateinit var torchSw: Switch
    private lateinit var stabSpin: Spinner
    private lateinit var brSeek: SeekBar
    private lateinit var brTxt: TextView
    private lateinit var evSeek: SeekBar
    private lateinit var evTxt: TextView
    private lateinit var zoomSeek: SeekBar
    private lateinit var zoomTxt: TextView
    private lateinit var statusTv: TextView
    private lateinit var timerTv: TextView
    private lateinit var recBtn: Button

    private var camId: String? = null
    private var chars: CameraCharacteristics? = null
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var builder: CaptureRequest.Builder? = null
    private var recorder: MediaRecorder? = null
    private var recUri: Uri? = null
    private var recPfd: ParcelFileDescriptor? = null
    private var recording = false
    private var evMin = 0
    private var evStep = 0f
    private var zLo = 1f
    private var zHi = 1f
    @Volatile private var evVal = 0
    @Volatile private var aeLock = false
    @Volatile private var torch = false
    @Volatile private var stab = 1
    @Volatile private var zoom = 1f
    private var t0 = 0L
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var ht: HandlerThread
    private lateinit var h: Handler

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hasCam() = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private fun status(s: String) = runOnUiThread { statusTv.text = s }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cm = getSystemService(CAMERA_SERVICE) as CameraManager
        ht = HandlerThread("cam").also { it.start() }
        h = Handler(ht.looper)
        buildUi()
        if (!hasCam()) requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
        else initCamera()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        if (hasCam()) initCamera() else status("Camera permission is needed. Allow it in Settings > Apps > HQ Recorder.")
    }

    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.LTGRAY); textSize = 13f; setPadding(0, dp(10), 0, dp(2)) }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.BLACK) }
        frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        tv = TextureView(this)
        frame.addView(tv, FrameLayout.LayoutParams(100, 100, Gravity.CENTER))
        frame.addOnLayoutChangeListener { _, l, t, r, bt, _, _, _, _ -> fit(r - l, bt - t) }
        root.addView(frame, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        tv.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP && v.width > 0 && v.height > 0) focusAt(e.x / v.width, e.y / v.height)
            true
        }

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(14)) }
        timerTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 20f; text = "0:00" }
        recBtn = Button(this).apply { text = "Record"; setOnClickListener { if (recording) stopRecording() else startRecording() } }
        statusTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; text = "Starting..." }
        val modeTv = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 13f; text = "2K 2560x1440 @ 60 fps. Tap the preview to focus." }

        hevcSw = Switch(this).apply { text = "HEVC (H.265)"; isChecked = true; setTextColor(Color.WHITE) }
        brTxt = TextView(this).apply { setTextColor(Color.WHITE); text = "Bitrate: 80 Mbps" }
        brSeek = SeekBar(this).apply {
            max = 140; progress = 70
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { brTxt.text = "Bitrate: ${10 + p} Mbps" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        stabSpin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Stabilization: Off", "Stabilization: Standard", "Stabilization: Strong (crops more)"))
            setSelection(1)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { stab = pos; push() }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        evTxt = TextView(this).apply { setTextColor(Color.WHITE); text = "Exposure: 0.0 EV" }
        evSeek = SeekBar(this).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    evVal = p + evMin
                    evTxt.text = "Exposure: " + String.format("%.1f", evVal * evStep) + " EV"
                    if (u) push()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        zoomTxt = TextView(this).apply { setTextColor(Color.WHITE); text = "Zoom: 1.0x" }
        zoomSeek = SeekBar(this).apply {
            max = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    zoom = zLo + (zHi - zLo) * p / 100f
                    zoomTxt.text = "Zoom: " + String.format("%.1f", zoom) + "x"
                    if (u) push()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        aeSw = Switch(this).apply {
            text = "Lock exposure"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, c -> aeLock = c; push() }
        }
        torchSw = Switch(this).apply {
            text = "Light (torch)"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, c -> torch = c; push() }
        }
        col.addView(timerTv); col.addView(recBtn); col.addView(statusTv); col.addView(modeTv)
        col.addView(hevcSw); col.addView(brTxt); col.addView(brSeek)
        col.addView(label("Stabilization")); col.addView(stabSpin)
        col.addView(evTxt); col.addView(evSeek); col.addView(zoomTxt); col.addView(zoomSeek)
        col.addView(aeSw); col.addView(torchSw)
        val sv = ScrollView(this).apply { addView(col) }
        root.addView(sv, LinearLayout.LayoutParams(dp(320), ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, hh: Int) {
                if (!hasCam()) return
                if (chars == null) initCamera() else if (device != null) startPreview() else openCamera()
            }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, hh: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
    }

    private fun fit(fw: Int, fh: Int) {
        if (fw <= 0 || fh <= 0) return
        var w = fw
        var hh = w * 9 / 16
        if (hh > fh) { hh = fh; w = hh * 16 / 9 }
        val lp = tv.layoutParams
        if (lp.width != w || lp.height != hh) { lp.width = w; lp.height = hh; tv.layoutParams = lp }
    }

    private fun initCamera() {
        camId = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
        val id = camId
        if (id == null) { status("No back camera found"); return }
        val c = cm.getCameraCharacteristics(id)
        chars = c
        val er = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: Range(0, 0)
        evStep = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0.1f
        evMin = er.lower
        evSeek.max = er.upper - er.lower
        evSeek.progress = -er.lower
        if (Build.VERSION.SDK_INT >= 30) {
            val zr = c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
            if (zr != null) { zLo = Math.max(1f, zr.lower); zHi = Math.min(8f, zr.upper) }
        }
        zoomSeek.visibility = if (zHi > zLo) View.VISIBLE else View.GONE
        zoomTxt.visibility = zoomSeek.visibility
        status("Ready. Press Record.")
        if (tv.isAvailable) openCamera()
    }

    @SuppressLint("MissingPermission")
    private fun openCamera() {
        val id = camId ?: return
        if (device != null || !hasCam()) return
        try {
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) { device = d; startPreview() }
                override fun onDisconnected(d: CameraDevice) { d.close(); device = null }
                override fun onError(d: CameraDevice, e: Int) { d.close(); device = null; status("Camera error $e") }
            }, h)
        } catch (e: Exception) { status("Open failed: ${e.message}") }
    }

    private fun closeSession() { try { session?.close() } catch (e: Exception) {}; session = null }
    private fun closeCamera() { closeSession(); try { device?.close() } catch (e: Exception) {}; device = null }

    private fun previewSize(): Size {
        val map = chars!!.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val ss = map.getOutputSizes(SurfaceTexture::class.java)
        return ss.filter { Math.abs(it.width.toDouble() / it.height - 16.0 / 9.0) < 0.02 && it.width <= 1920 }
            .maxByOrNull { it.width } ?: ss[0]
    }

    private fun setCommon(b: CaptureRequest.Builder) {
        val c = chars ?: return
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        if (c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)?.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO) == true)
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
        b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evVal)
        b.set(CaptureRequest.CONTROL_AE_LOCK, aeLock)
        b.set(CaptureRequest.FLASH_MODE, if (torch) CaptureRequest.FLASH_MODE_TORCH else CaptureRequest.FLASH_MODE_OFF)
        if (Build.VERSION.SDK_INT >= 30) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom)
        val vs = c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES) ?: IntArray(0)
        var mode = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF
        if (stab >= 1 && vs.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON))
            mode = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON
        if (stab == 2 && Build.VERSION.SDK_INT >= 33 &&
            vs.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION))
            mode = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION
        b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, mode)
        val ois = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
        if (ois?.contains(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON) == true)
            b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                if (stab >= 1) CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON else CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF)
    }

    private fun push() {
        val s = session ?: return
        val b = builder ?: return
        try {
            setCommon(b)
            s.setRepeatingRequest(b.build(), null, h)
        } catch (e: Exception) { status("Request failed: ${e.message}") }
    }

    private fun focusAt(nx0: Float, ny0: Float) {
        val c = chars ?: return
        val b = builder ?: return
        val s = session ?: return
        val ar = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return
        var nx = nx0
        var ny = ny0
        if (tv.rotation == 180f) { nx = 1f - nx; ny = 1f - ny }
        var cw = ar.width()
        var ch = ar.height()
        if (cw * 9 > ch * 16) cw = ch * 16 / 9 else ch = cw * 9 / 16
        val cl = ar.left + (ar.width() - cw) / 2
        val ct = ar.top + (ar.height() - ch) / 2
        val x = (cl + nx * cw).toInt()
        val y = (ct + ny * ch).toInt()
        val half = ar.width() / 14
        val r = Rect(Math.max(ar.left, x - half), Math.max(ar.top, y - half), Math.min(ar.right - 1, x + half), Math.min(ar.bottom - 1, y + half))
        try {
            val mr = arrayOf(MeteringRectangle(r, MeteringRectangle.METERING_WEIGHT_MAX - 1))
            b.set(CaptureRequest.CONTROL_AF_REGIONS, mr)
            b.set(CaptureRequest.CONTROL_AE_REGIONS, mr)
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START)
            setCommon(b)
            s.capture(b.build(), null, h)
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE)
            push()
            status("Focusing at tapped point")
        } catch (e: Exception) { status("Focus failed: ${e.message}") }
    }

    private fun startPreview() {
        val d = device ?: return
        val t = tv.surfaceTexture ?: return
        if (chars == null) return
        closeSession()
        runOnUiThread { tv.rotation = if (windowManager.defaultDisplay.rotation == Surface.ROTATION_270) 180f else 0f }
        try {
            val ps = previewSize()
            t.setDefaultBufferSize(ps.width, ps.height)
            val surf = Surface(t)
            d.createCaptureSession(listOf(surf), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    try {
                        val b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                        b.addTarget(surf); builder = b; push()
                    } catch (e: Exception) { status("Preview failed: ${e.message}") }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { status("Preview config failed") }
            }, h)
        } catch (e: Exception) { status("Preview failed: ${e.message}") }
    }

    private fun orientationHint(): Int {
        val rot = windowManager.defaultDisplay.rotation * 90
        val so = chars!!.get(CameraCharacteristics.SENSOR_ORIENTATION)!!
        return (so - rot + 360) % 360
    }

    private fun discardRec() {
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        recUri?.let { try { contentResolver.delete(it, null, null) } catch (e: Exception) {} }
        recUri = null
        recording = false
    }

    private fun fail(msg: String) {
        discardRec()
        runOnUiThread { onRecState(false) }
        status(msg)
        startPreview()
    }

    private fun onRecState(on: Boolean) {
        recBtn.text = if (on) "Stop" else "Record"
        hevcSw.isEnabled = !on
        brSeek.isEnabled = !on
        ui.removeCallbacksAndMessages(null)
        if (on) {
            t0 = System.currentTimeMillis()
            ui.post(object : Runnable {
                override fun run() {
                    val s = (System.currentTimeMillis() - t0) / 1000
                    timerTv.text = "REC " + s / 60 + ":" + String.format("%02d", s % 60)
                    ui.postDelayed(this, 500)
                }
            })
        } else timerTv.text = "0:00"
    }

    private fun startRecording() {
        val d = device ?: return
        val t = tv.surfaceTexture ?: return
        closeSession()
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "HQ_" + System.currentTimeMillis() + ".mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HQRecorder")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
            val pfd = contentResolver.openFileDescriptor(uri, "w")!!
            val mr = MediaRecorder()
            recorder = mr; recUri = uri; recPfd = pfd
            mr.setOnErrorListener { _, w, e -> status("Recorder error $w / $e") }
            val audio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (audio) mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setOutputFile(pfd.fileDescriptor)
            mr.setVideoEncodingBitRate((10 + brSeek.progress) * 1_000_000)
            mr.setVideoFrameRate(FPS)
            mr.setVideoSize(VW, VH)
            mr.setVideoEncoder(if (hevcSw.isChecked) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
            if (audio) {
                mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                mr.setAudioChannels(2)
                mr.setAudioEncodingBitRate(256000)
                mr.setAudioSamplingRate(48000)
            }
            mr.setOrientationHint(orientationHint())
            mr.prepare()
            val ps = previewSize()
            t.setDefaultBufferSize(ps.width, ps.height)
            val pSurf = Surface(t)
            val rSurf = mr.surface
            val cb = object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    try {
                        val b = d.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                        b.addTarget(pSurf); b.addTarget(rSurf)
                        b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(FPS, FPS))
                        builder = b
                        push()
                        mr.start()
                        recording = true
                        runOnUiThread { onRecState(true) }
                        status("Recording 2K @ 60 fps, " + (if (hevcSw.isChecked) "HEVC " else "H.264 ") + (10 + brSeek.progress) + " Mbps")
                    } catch (e: Exception) { fail("Could not start: ${e.message}") }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { fail("Camera rejected this setup. Try H.264 or lower the bitrate.") }
            }
            d.createCaptureSession(listOf(pSurf, rSurf), cb, h)
        } catch (e: Exception) { fail("Setup failed: ${e.message}") }
    }

    private fun stopRecording() {
        if (!recording) return
        recording = false
        try { session?.stopRepeating(); session?.abortCaptures() } catch (e: Exception) {}
        var ok = true
        var err = ""
        try { recorder?.stop() } catch (e: Exception) { ok = false; err = e.message ?: e.javaClass.simpleName }
        val bytes = try { recPfd?.statSize ?: 0L } catch (e: Exception) { 0L }
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        val u = recUri
        recUri = null
        if (u != null) {
            if (ok) {
                val cv = ContentValues(); cv.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(u, cv, null, null)
            } else contentResolver.delete(u, null, null)
        }
        closeSession()
        onRecState(false)
        val secs = Math.max(1.0, (System.currentTimeMillis() - t0) / 1000.0)
        status(if (ok) "Saved: " + String.format("%.1f", bytes / 1048576.0) + " MB in " + String.format("%.0f", secs) +
            " s (avg " + String.format("%.1f", bytes * 8 / 1e6 / secs) + " Mbps). Movies/HQRecorder"
        else "Failed, nothing saved: $err. Try H.264, a lower bitrate, or Stabilization: Off.")
        startPreview()
    }

    override fun onResume() {
        super.onResume()
        if (hasCam()) {
            if (chars == null) initCamera() else if (tv.isAvailable) openCamera()
        }
    }

    override fun onPause() {
        if (recording) stopRecording()
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        ht.quitSafely()
        super.onDestroy()
    }
}
