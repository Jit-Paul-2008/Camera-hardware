package com.hq.recorder

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.DynamicRangeProfiles
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import java.io.FileDescriptor
import java.nio.ByteBuffer
import java.util.concurrent.Executor

class Mux(fd: FileDescriptor, private val hasAudio: Boolean, private val common: Boolean, hint: Int) {
    private val m = MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private var vt = -1
    private var at = -1
    private var vFirst = -1L
    private var aFirst = -1L
    private var vArrival = 0L
    private var started = false
    private var baseV = 0L
    private var baseA = 0L
    private class P(val video: Boolean, val data: ByteArray, val flags: Int, val pts: Long)
    private val pending = ArrayList<P>()
    init { m.setOrientationHint(hint) }

    @Synchronized fun addTrack(video: Boolean, f: MediaFormat) {
        if (video) vt = m.addTrack(f) else at = m.addTrack(f)
        tryStart()
    }

    private fun tryStart() {
        if (started || vt < 0 || vFirst < 0) return
        if (hasAudio && (at < 0 || aFirst < 0)) return
        if (hasAudio) {
            if (Math.abs(vFirst - vArrival) < 3_000_000L) {
                val b = Math.min(vFirst, aFirst); baseV = b; baseA = b
            } else {
                val vCap = vArrival - 100_000L
                val tz = Math.min(vCap, aFirst)
                baseV = vFirst - (vCap - tz)
                baseA = tz
            }
        } else { baseV = vFirst; baseA = 0L }
        m.start()
        started = true
        for (p in pending) out(p)
        pending.clear()
    }

    private fun out(p: P) {
        val bi = MediaCodec.BufferInfo()
        val t = Math.max(0L, p.pts - (if (p.video) baseV else baseA))
        bi.set(0, p.data.size, t, p.flags)
        m.writeSampleData(if (p.video) vt else at, ByteBuffer.wrap(p.data), bi)
    }

    @Synchronized fun write(video: Boolean, bb: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (info.size <= 0) return
        val arr = ByteArray(info.size)
        bb.position(info.offset)
        bb.limit(info.offset + info.size)
        bb.get(arr)
        if (video && vFirst < 0) { vFirst = info.presentationTimeUs; vArrival = SystemClock.elapsedRealtimeNanos() / 1000 }
        if (!video && aFirst < 0) aFirst = info.presentationTimeUs
        val p = P(video, arr, info.flags, info.presentationTimeUs)
        if (started) out(p) else { pending.add(p); tryStart() }
    }

    @Synchronized fun stop(): Boolean {
        var ok = started
        try { if (started) m.stop() } catch (e: Exception) { ok = false }
        try { m.release() } catch (e: Exception) {}
        return ok
    }
}

class MainActivity : Activity() {

    private val VW = 2560
    private val VH = 1440
    private val FPS = 60

    private lateinit var cm: CameraManager
    private lateinit var tv: TextureView
    private lateinit var frame: FrameLayout
    private lateinit var aeSw: Switch
    private lateinit var torchSw: Switch
    private lateinit var stabSpin: Spinner
    private lateinit var brSeek: SeekBar
    private lateinit var brTxt: TextView
    private lateinit var evSeek: SeekBar
    private lateinit var evTxt: TextView
    private lateinit var zoomSeek: SeekBar
    private lateinit var zoomTxt: TextView
    private lateinit var statusTv: TextView
    private lateinit var capTv: TextView
    private lateinit var timerTv: TextView
    private lateinit var recBtn: Button

    private var camId: String? = null
    private var chars: CameraCharacteristics? = null
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var builder: CaptureRequest.Builder? = null
    private var hlgOk = false

    private var encoder: MediaCodec? = null
    private var aCodec: MediaCodec? = null
    private var aRec: AudioRecord? = null
    private var mux: Mux? = null
    private var vThread: Thread? = null
    private var aThread: Thread? = null
    @Volatile private var audioRun = false
    private var recUri: Uri? = null
    private var recPfd: ParcelFileDescriptor? = null
    private var recMode = 2
    @Volatile private var recording = false

    private var evMin = 0
    private var evStep = 0f
    private var zLo = 1f
    private var zHi = 1f
    @Volatile private var evVal = 0
    @Volatile private var aeLock = false
    @Volatile private var torch = false
    @Volatile private var stab = 1
    @Volatile private var zoom = 1f
    private var t0 = 0L
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var ht: HandlerThread
    private lateinit var h: Handler

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hasCam() = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private fun hasMic() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun status(s: String) = runOnUiThread { statusTv.text = s }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cm = getSystemService(CAMERA_SERVICE) as CameraManager
        ht = HandlerThread("cam").also { it.start() }
        h = Handler(ht.looper)
        buildUi()
        if (!hasCam()) requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
        else initCamera()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        if (hasCam()) initCamera() else status("Camera permission is needed. Allow it in Settings > Apps > HQ Recorder.")
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.BLACK) }
        frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        tv = TextureView(this)
        frame.addView(tv, FrameLayout.LayoutParams(100, 100, Gravity.CENTER))
        frame.addOnLayoutChangeListener { _, l, t, r, bt, _, _, _, _ -> fit(r - l, bt - t) }
        root.addView(frame, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        tv.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP && v.width > 0 && v.height > 0) focusAt(e.x / v.width, e.y / v.height)
            true
        }

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(14)) }
        timerTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 20f; text = "0:00" }
        recBtn = Button(this).apply { text = "Record"; setOnClickListener { if (recording) stopRecording() else startRecording(if (hlgOk) 0 else 2) } }
        statusTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; text = "Starting..." }
        capTv = TextView(this).apply { setTextColor(Color.parseColor("#8FD3FF")); textSize = 13f; setPadding(0, dp(6), 0, dp(6)) }
        val modeTv = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 13f; text = "2K 2560x1440 @ 60 fps, HEVC. Tap the preview to focus." }

        brTxt = TextView(this).apply { setTextColor(Color.WHITE); text = "Bitrate: 100 Mbps" }
        brSeek = SeekBar(this).apply {
            max = 140; progress = 90
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { brTxt.text = "Bitrate: ${10 + p} Mbps" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        stabSpin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Stabilization: Off", "Stabilization: Standard", "Stabilization: Strong (crops more)"))
            setSelection(1)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { stab = pos; push() }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        evTxt = TextView(this).apply { setTextColor(Color.WHITE); text = "Exposure: 0.0 EV" }
        evSeek = SeekBar(this).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    evVal = p + evMin
                    evTxt.text = "Exposure: " + String.format("%.1f", evVal * evStep) + " EV"
                    if (u) push()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        zoomTxt = TextView(this).apply { setTextColor(Color.WHITE); text = "Zoom: 1.0x" }
        zoomSeek = SeekBar(this).apply {
            max = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    zoom = zLo + (zHi - zLo) * p / 100f
                    zoomTxt.text = "Zoom: " + String.format("%.1f", zoom) + "x"
                    if (u) push()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        aeSw = Switch(this).apply {
            text = "Lock exposure"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, c -> aeLock = c; push() }
        }
        torchSw = Switch(this).apply {
            text = "Light (torch)"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, c -> torch = c; push() }
        }
        col.addView(timerTv); col.addView(recBtn); col.addView(statusTv); col.addView(capTv); col.addView(modeTv)
        col.addView(brTxt); col.addView(brSeek); col.addView(stabSpin)
        col.addView(evTxt); col.addView(evSeek); col.addView(zoomTxt); col.addView(zoomSeek)
        col.addView(aeSw); col.addView(torchSw)
        val sv = ScrollView(this).apply { addView(col) }
        root.addView(sv, LinearLayout.LayoutParams(dp(320), ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, hh: Int) {
                if (!hasCam()) return
                if (chars == null) initCamera() else if (device != null) startPreview() else openCamera()
            }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, hh: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
    }

    private fun fit(fw: Int, fh: Int) {
        if (fw <= 0 || fh <= 0) return
        var w = fw
        var hh = w * 9 / 16
        if (hh > fh) { hh = fh; w = hh * 16 / 9 }
        val lp = tv.layoutParams
        if (lp.width != w || lp.height != hh) { lp.width = w; lp.height = hh; tv.layoutParams = lp }
    }

    private fun encoderHasMain10(): Boolean {
        try {
            for (info in MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos) {
                if (!info.isEncoder || !info.supportedTypes.contains(MediaFormat.MIMETYPE_VIDEO_HEVC)) continue
                val caps = info.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_HEVC)
                if (caps.profileLevels.any { it.profile == MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10 }) return true
            }
        } catch (e: Exception) {}
        return false
    }

    private fun initCamera() {
        camId = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
        val id = camId
        if (id == null) { status("No back camera found"); return }
        val c = cm.getCameraCharacteristics(id)
        chars = c
        val er = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: Range(0, 0)
        evStep = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0.1f
        evMin = er.lower
        evSeek.max = er.upper - er.lower
        evSeek.progress = -er.lower
        if (Build.VERSION.SDK_INT >= 30) {
            val zr = c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
            if (zr != null) { zLo = Math.max(1f, zr.lower); zHi = Math.min(8f, zr.upper) }
        }
        zoomSeek.visibility = if (zHi > zLo) View.VISIBLE else View.GONE
        zoomTxt.visibility = zoomSeek.visibility
        var camHlg = false
        if (Build.VERSION.SDK_INT >= 33) {
            val dr = c.get(CameraCharacteristics.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES)
            camHlg = dr?.supportedProfiles?.contains(DynamicRangeProfiles.HLG10) == true
        }
        val encOk = encoderHasMain10()
        hlgOk = camHlg && encOk
        capTv.text = "10-bit HLG: camera " + (if (camHlg) "yes" else "no") + ", encoder " + (if (encOk) "yes" else "no") +
            ". Will record " + (if (hlgOk) "10-bit HLG (BT.2020)." else "8-bit Rec.709.")
        status("Ready. Press Record.")
        if (tv.isAvailable) openCamera()
    }

    @SuppressLint("MissingPermission")
    private fun openCamera() {
        val id = camId ?: return
        if (device != null || !hasCam()) return
        try {
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) { device = d; startPreview() }
                override fun onDisconnected(d: CameraDevice) { d.close(); device = null }
                override fun onError(d: CameraDevice, e: Int) { d.close(); device = null; status("Camera error $e") }
            }, h)
        } catch (e: Exception) { status("Open failed: ${e.message}") }
    }

    private fun closeSession() { try { session?.close() } catch (e: Exception) {}; session = null }
    private fun closeCamera() { closeSession(); try { device?.close() } catch (e: Exception) {}; device = null }

    private fun previewSize(): Size {
        val map = chars!!.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val ss = map.getOutputSizes(SurfaceTexture::class.java)
        return ss.filter { Math.abs(it.width.toDouble() / it.height - 16.0 / 9.0) < 0.02 && it.width <= 1920 }
            .maxByOrNull { it.width } ?: ss[0]
    }

    private fun setCommon(b: CaptureRequest.Builder) {
        val c = chars ?: return
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        if (c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)?.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO) == true)
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
        b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evVal)
        b.set(CaptureRequest.CONTROL_AE_LOCK, aeLock)
        b.set(CaptureRequest.FLASH_MODE, if (torch) CaptureRequest.FLASH_MODE_TORCH else CaptureRequest.FLASH_MODE_OFF)
        if (Build.VERSION.SDK_INT >= 30) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom)
        val vs = c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES) ?: IntArray(0)
        var mode = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF
        if (stab >= 1 && vs.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON))
            mode = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON
        if (stab == 2 && Build.VERSION.SDK_INT >= 33 &&
            vs.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION))
            mode = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION
        b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, mode)
        val ois = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
        if (ois?.contains(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON) == true)
            b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                if (stab >= 1) CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON else CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_OFF)
    }

    private fun push() {
        val s = session ?: return
        val b = builder ?: return
        try {
            setCommon(b)
            s.setRepeatingRequest(b.build(), null, h)
        } catch (e: Exception) { status("Request failed: ${e.message}") }
    }

    private fun focusAt(nx0: Float, ny0: Float) {
        val c = chars ?: return
        val b = builder ?: return
        val s = session ?: return
        val ar = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return
        var nx = nx0
        var ny = ny0
        if (tv.rotation == 180f) { nx = 1f - nx; ny = 1f - ny }
        var cw = ar.width()
        var ch = ar.height()
        if (cw * 9 > ch * 16) cw = ch * 16 / 9 else ch = cw * 9 / 16
        val cl = ar.left + (ar.width() - cw) / 2
        val ct = ar.top + (ar.height() - ch) / 2
        val x = (cl + nx * cw).toInt()
        val y = (ct + ny * ch).toInt()
        val half = ar.width() / 14
        val r = Rect(Math.max(ar.left, x - half), Math.max(ar.top, y - half), Math.min(ar.right - 1, x + half), Math.min(ar.bottom - 1, y + half))
        try {
            val mr = arrayOf(MeteringRectangle(r, MeteringRectangle.METERING_WEIGHT_MAX - 1))
            b.set(CaptureRequest.CONTROL_AF_REGIONS, mr)
            b.set(CaptureRequest.CONTROL_AE_REGIONS, mr)
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START)
            setCommon(b)
            s.capture(b.build(), null, h)
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE)
            push()
            status("Focusing at tapped point")
        } catch (e: Exception) { status("Focus failed: ${e.message}") }
    }

    private fun startPreview() {
        val d = device ?: return
        val t = tv.surfaceTexture ?: return
        if (chars == null) return
        closeSession()
        runOnUiThread { tv.rotation = if (windowManager.defaultDisplay.rotation == Surface.ROTATION_270) 180f else 0f }
        try {
            val ps = previewSize()
            t.setDefaultBufferSize(ps.width, ps.height)
            val surf = Surface(t)
            d.createCaptureSession(listOf(surf), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    try {
                        val b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                        b.addTarget(surf); builder = b; push()
                    } catch (e: Exception) { status("Preview failed: ${e.message}") }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { status("Preview config failed") }
            }, h)
        } catch (e: Exception) { status("Preview failed: ${e.message}") }
    }

    private fun orientationHint(): Int {
        val rot = windowManager.defaultDisplay.rotation * 90
        val so = chars!!.get(CameraCharacteristics.SENSOR_ORIENTATION)!!
        return (so - rot + 360) % 360
    }

    private fun onRecState(on: Boolean) {
        recBtn.text = if (on) "Stop" else "Record"
        recBtn.isEnabled = true
        brSeek.isEnabled = !on
        ui.removeCallbacksAndMessages(null)
        if (on) {
            t0 = System.currentTimeMillis()
            ui.post(object : Runnable {
                override fun run() {
                    val s = (System.currentTimeMillis() - t0) / 1000
                    timerTv.text = "REC " + s / 60 + ":" + String.format("%02d", s % 60)
                    ui.postDelayed(this, 500)
                }
            })
        } else timerTv.text = "0:00"
    }

    private fun teardown(deleteFile: Boolean) {
        audioRun = false
        try { encoder?.release() } catch (e: Exception) {}
        encoder = null
        try { aCodec?.release() } catch (e: Exception) {}
        aCodec = null
        try { aRec?.release() } catch (e: Exception) {}
        aRec = null
        try { mux?.stop() } catch (e: Exception) {}
        mux = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        if (deleteFile) recUri?.let { try { contentResolver.delete(it, null, null) } catch (e: Exception) {} }
        recUri = null
        recording = false
    }

    private fun giveUp(mode: Int, msg: String) {
        teardown(true)
        if (mode < 2 && hlgOk) {
            status(msg + " Retrying " + (if (mode == 0) "without preview..." else "in 8-bit..."))
            runOnUiThread { startRecording(mode + 1) }
        } else {
            runOnUiThread { onRecState(false) }
            status(msg)
            startPreview()
        }
    }

    private fun drainVideo(enc: MediaCodec, mx: Mux) {
        val info = MediaCodec.BufferInfo()
        while (true) {
            val i = try { enc.dequeueOutputBuffer(info, 10000) } catch (e: Exception) { break }
            if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                mx.addTrack(true, enc.outputFormat)
            } else if (i >= 0) {
                val b = enc.getOutputBuffer(i)
                if (b != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) mx.write(true, b, info)
                enc.releaseOutputBuffer(i, false)
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
            }
        }
    }

    private fun audioLoop(ac: MediaCodec, ar: AudioRecord, mx: Mux) {
        val info = MediaCodec.BufferInfo()
        var eosSent = false
        var done = false
        var lastPts = 0L
        ar.startRecording()
        while (!done) {
            if (!eosSent) {
                val ii = ac.dequeueInputBuffer(5000)
                if (ii >= 0) {
                    val buf = ac.getInputBuffer(ii)!!
                    buf.clear()
                    if (audioRun) {
                        val n = ar.read(buf, buf.capacity())
                        if (n > 0) {
                            lastPts = SystemClock.elapsedRealtimeNanos() / 1000 - (n / 4) * 1_000_000L / 48000
                            ac.queueInputBuffer(ii, 0, n, lastPts, 0)
                        } else ac.queueInputBuffer(ii, 0, 0, lastPts, 0)
                    } else {
                        ac.queueInputBuffer(ii, 0, 0, lastPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        eosSent = true
                    }
                }
            }
            while (true) {
                val oi = try { ac.dequeueOutputBuffer(info, 0) } catch (e: Exception) { done = true; break }
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    mx.addTrack(false, ac.outputFormat)
                } else if (oi >= 0) {
                    val b = ac.getOutputBuffer(oi)
                    if (b != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) mx.write(false, b, info)
                    ac.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) { done = true; break }
                } else break
            }
        }
        try { ar.stop() } catch (e: Exception) {}
    }

    // mode 0: HLG 10-bit + preview, 1: HLG 10-bit without preview, 2: 8-bit Rec.709
    private fun startRecording(mode: Int) {
        val d = device ?: return
        val t = tv.surfaceTexture ?: return
        closeSession()
        teardown(true)
        recMode = mode
        val hlg = mode < 2
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "HQ_" + System.currentTimeMillis() + ".mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HQRecorder")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
            recUri = uri
            val pfd = contentResolver.openFileDescriptor(uri, "w")!!
            recPfd = pfd

            val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_HEVC, VW, VH)
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, (10 + brSeek.progress) * 1_000_000)
            fmt.setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            fmt.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            fmt.setInteger(MediaFormat.KEY_PRIORITY, 0)
            fmt.setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
            if (hlg) {
                fmt.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10)
                fmt.setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT2020)
                fmt.setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_HLG)
            } else {
                fmt.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.HEVCProfileMain)
                fmt.setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)
                fmt.setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_SDR_VIDEO)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_HEVC)
            encoder = enc
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val rSurf = enc.createInputSurface()
            enc.start()

            var audio = false
            if (hasMic()) {
                try {
                    val minBuf = AudioRecord.getMinBufferSize(48000, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                    val ar = AudioRecord(MediaRecorder.AudioSource.MIC, 48000, AudioFormat.CHANNEL_IN_STEREO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(minBuf * 4, 32768))
                    val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, 48000, 2)
                    af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    af.setInteger(MediaFormat.KEY_BIT_RATE, 256000)
                    af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                    val ac = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
                    ac.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    ac.start()
                    aRec = ar; aCodec = ac; audio = true
                } catch (e: Exception) { audio = false }
            }
            val realtime = chars!!.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE) == CameraMetadata.SENSOR_INFO_TIMESTAMP_SOURCE_REALTIME
            val mx = Mux(pfd.fileDescriptor, audio, realtime, orientationHint())
            mux = mx

            val ps = previewSize()
            t.setDefaultBufferSize(ps.width, ps.height)
            val pSurf = Surface(t)
            val usePrev = mode != 1
            val cb = object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    try {
                        val b = d.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                        if (usePrev) b.addTarget(pSurf)
                        b.addTarget(rSurf)
                        b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, Range(FPS, FPS))
                        builder = b
                        recording = true
                        audioRun = true
                        vThread = Thread { drainVideo(enc, mx) }.also { it.start() }
                        val ac2 = aCodec
                        val ar2 = aRec
                        if (audio && ac2 != null && ar2 != null) aThread = Thread { audioLoop(ac2, ar2, mx) }.also { it.start() }
                        push()
                        runOnUiThread { onRecState(true) }
                        status("Recording 2K60 " + (if (hlg) "10-bit HLG" else "8-bit Rec.709") + (if (usePrev) "" else " (no preview in this mode)") +
                            ", " + (10 + brSeek.progress) + " Mbps")
                    } catch (e: Exception) { giveUp(mode, "Could not start: ${e.message}.") }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { giveUp(mode, "Camera rejected this setup.") }
            }
            if (hlg && Build.VERSION.SDK_INT >= 33) {
                val oc = OutputConfiguration(rSurf)
                oc.setDynamicRangeProfile(DynamicRangeProfiles.HLG10)
                val list = ArrayList<OutputConfiguration>()
                list.add(oc)
                if (usePrev) list.add(OutputConfiguration(pSurf))
                d.createCaptureSession(SessionConfiguration(SessionConfiguration.SESSION_REGULAR, list, Executor { r -> h.post(r) }, cb))
            } else {
                val surfaces = if (usePrev) listOf(pSurf, rSurf) else listOf(rSurf)
                d.createCaptureSession(surfaces, cb, h)
            }
        } catch (e: Exception) { giveUp(mode, "Setup failed: ${e.message}.") }
    }

    private fun stopRecording() {
        if (!recording) return
        recording = false
        recBtn.isEnabled = false
        try { session?.stopRepeating(); session?.abortCaptures() } catch (e: Exception) {}
        closeSession()
        val enc = encoder
        val vt = vThread
        val at = aThread
        val mx = mux
        val pfd = recPfd
        val uri = recUri
        val ac = aCodec
        val ar = aRec
        val mode = recMode
        val secs = Math.max(1.0, (System.currentTimeMillis() - t0) / 1000.0)
        Thread {
            try { enc?.signalEndOfInputStream() } catch (e: Exception) {}
            audioRun = false
            try { vt?.join(4000) } catch (e: Exception) {}
            try { at?.join(4000) } catch (e: Exception) {}
            val ok = mx?.stop() ?: false
            try { enc?.stop() } catch (e: Exception) {}
            try { enc?.release() } catch (e: Exception) {}
            try { ac?.stop() } catch (e: Exception) {}
            try { ac?.release() } catch (e: Exception) {}
            try { ar?.release() } catch (e: Exception) {}
            val bytes = try { pfd?.statSize ?: 0L } catch (e: Exception) { 0L }
            try { pfd?.close() } catch (e: Exception) {}
            if (uri != null) {
                try {
                    if (ok && bytes > 0) {
                        val cv = ContentValues(); cv.put(MediaStore.Video.Media.IS_PENDING, 0)
                        contentResolver.update(uri, cv, null, null)
                    } else contentResolver.delete(uri, null, null)
                } catch (e: Exception) {}
            }
            encoder = null; aCodec = null; aRec = null; mux = null; vThread = null; aThread = null; recPfd = null; recUri = null
            runOnUiThread {
                onRecState(false)
                statusTv.text = if (ok && bytes > 0)
                    "Saved " + (if (mode < 2) "10-bit HLG (tag: BT.2020 HLG)" else "8-bit (tag: BT.709)") + ": " +
                        String.format("%.1f", bytes / 1048576.0) + " MB, avg " + String.format("%.1f", bytes * 8 / 1e6 / secs) + " Mbps. Movies/HQRecorder"
                else "Failed, nothing saved. Try a lower bitrate."
            }
            startPreview()
        }.start()
    }

    override fun onResume() {
        super.onResume()
        if (hasCam()) {
            if (chars == null) initCamera() else if (tv.isAvailable) openCamera()
        }
    }

    override fun onPause() {
        if (recording) stopRecording()
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        ht.quitSafely()
        super.onDestroy()
    }
}
